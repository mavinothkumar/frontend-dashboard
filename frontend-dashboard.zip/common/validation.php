<?php

/**
 * @param $request
 * @param $rules
 */
function fed_validate_request($request,$rules)
{
    return;
}